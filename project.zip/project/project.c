/*
 * project.c
 *
 * Created: 1/25/2025 6:37:41 PM
 * Author: kian
 */
#include <mega16a.h>
#include <delay.h>
#include <alcd.h>
#include <stdio.h>

#define S1 1
#define S2 2
#define S3 3
#define HEATER_LOW PORTD.0
#define HEATER_HIGH PORTD.1
#define COOLER_4RPS PORTD.2
#define COOLER_6RPS PORTD.3
#define COOLER_8RPS PORTD.4
#define COOLER_THERMO PORTD.5
#define HEATER_THERMO PORTD.6

unsigned char temp = 0;
unsigned char buffer[20];
unsigned char state = 0;
unsigned char C_state = 0;

#define ADC_VREF_TYPE ((1 << REFS1) | (1 << REFS0) | (1 << ADLAR))

// Function prototypes
unsigned char read_adc(unsigned char adc_input);
void display_state_on_second_line(const char *state_message);
void update_state_display();

unsigned char read_adc(unsigned char adc_input) {
    ADMUX = adc_input | ADC_VREF_TYPE;
    delay_us(10);
    ADCSRA |= (1 << ADSC);
    while ((ADCSRA & (1 << ADIF)) == 0);
    ADCSRA |= (1 << ADIF);
    return ADCH;
}

// Function to display heater or cooler state on the second line of the LCD
void display_state_on_second_line(const char *state_message) {
    lcd_gotoxy(0, 1); // Move cursor to the second line
    lcd_puts(state_message); // Display the state message on the second line
}

// Function to update the second line with heater/cooler state
void update_state_display() {
    if (state == S1) {
        display_state_on_second_line("System Off");
    } else if (state == S2) {
        if (C_state == S1) {
            display_state_on_second_line("Cooler Low");
        } else if (C_state == S2) {
            display_state_on_second_line("Cooler Mid");
        } else if (C_state == S3) {
            display_state_on_second_line("Cooler High");
        }
    } else if (state == S3) {
        if (temp < 10) {
            display_state_on_second_line("Heater High");
        } else if (temp < 15) {
            display_state_on_second_line("Heater Low");
        }
    }
}

void main(void) {
    DDRA = 0x00; // Set PORTA as input for ADC
    PORTA = 0x00; // Disable pull-up resistors on PORTA

    DDRB = 0x00; // Set PORTB as input
    PORTB = 0x00; // Initialize all pins of PORTB to low

    DDRC = 0x00; // Set PORTC as input
    PORTC = 0x00; // Initialize all pins of PORTC to low

    DDRD = 255; // Set all pins of PORTD as output
    PORTD = 0x00; // Initialize all pins of PORTD to low

    ADMUX = ADC_VREF_TYPE;
    ADCSRA = ((1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)); // Enable ADC and set prescaler

    lcd_init(16); // Initialize LCD

    while(1) {
        temp = read_adc(0); // Read temperature from ADC channel 0
        sprintf(buffer, "Temp=%d", temp); // Format temperature string
        lcd_clear(); // Clear LCD
        lcd_puts(buffer); // Display temperature on first line

        // Determine state based on temperature
        if(temp < 15)
            state = S3; // Heater mode if temp < 15?C

        if((state == S3)&&(temp > 30))
            state = S1; // Turn off if temp > 30?C in heater mode

        if(temp > 35)
            state = S2; // Cooler mode if temp > 35?C

        if((state == S2)&&(temp < 25))
            state = S1; // Turn off if temp < 25?C in cooler mode

        // Control logic for heating and cooling based on state
        if(state == S1){
            HEATER_LOW = HEATER_HIGH = COOLER_4RPS = COOLER_6RPS =
            COOLER_8RPS = COOLER_THERMO = HEATER_THERMO = 0;
        }

        if(state == S2){
            if(temp > 35)
                C_state = S1;

            if((C_state == S1)&&(temp > 40))
                C_state = S2;

            if((C_state == S2)&&(temp > 45))
                C_state = S3;

            if((C_state == S3)&&(temp < 40))
                C_state = S2;

            if((C_state == S2)&&(temp < 35))
                C_state = S1;

            if(C_state == S1){
                COOLER_4RPS=COOLER_THERMO=1;
                COOLER_6RPS=COOLER_8RPS=HEATER_LOW=HEATER_HIGH=HEATER_THERMO=0;
            }

            if(C_state == S2){
                COOLER_6RPS=COOLER_THERMO=1;
                COOLER_4RPS=COOLER_8RPS=HEATER_LOW=HEATER_HIGH=HEATER_THERMO=0;
            }

            if(C_state == S3){
                COOLER_8RPS=COOLER_THERMO=1;
                COOLER_4RPS=COOLER_6RPS=HEATER_LOW=HEATER_HIGH=HEATER_THERMO=0;
            }
        }

        if(state == S3){
            if(temp < 10){
                HEATER_HIGH=HEATER_THERMO=1;
                HEATER_LOW=COOLER_4RPS=COOLER_6RPS=COOLER_8RPS=COOLER_THERMO=0;
            }
            
            if((temp < 15)&&(temp >=10)){
                HEATER_LOW=HEATER_THERMO=1;
                HEATER_HIGH=COOLER_4RPS=COOLER_6RPS=COOLER_8RPS=COOLER_THERMO=0;
            }
        }

        update_state_display(); // Update the second line with current state
        delay_ms(300); // Delay for stability in LCD updates
    }
}
